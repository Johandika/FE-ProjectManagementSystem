import{j as t}from"./index-b009c0ac.js";function r(){return t.jsx("div",{children:"test"})}export{r as default};
