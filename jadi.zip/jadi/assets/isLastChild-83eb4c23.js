function n(t,i){return t.length===i+1}export{n as i};
